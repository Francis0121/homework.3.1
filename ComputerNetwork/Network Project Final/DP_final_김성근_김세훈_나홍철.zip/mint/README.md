===========================
			Mint

	20093267 Sung Geun Kim
	20093268 Se Hoon Kim
	20093284 Hong Cheol Na
===========================

1. Compile 시 $ make clean을 한뒤 compile을 해야합니다.
Compile은 $ make 로 Compile 가능합니다.

2. 실행파일  sever.exe , client.exe 이고 실행은
----------------
$ ./server.exe
$ ./client.exe
----------------
로 하면됩니다.

3. Source Code는 code 폴더안에 있으며, client와 server부분으로
code가 나눠져 있습니다.

4. 실행방법은 DP_Report.docx 에 User Manual을 참조하시면 됩니다.