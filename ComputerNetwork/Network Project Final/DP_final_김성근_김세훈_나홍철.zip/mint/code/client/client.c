//
//  client.c
//  mintClient
//
//  Created by 김세훈 on 2014. 5. 22..
//  Copyright (c) 2014년 김세훈. All rights reserved.
//

#include <stdio.h>
