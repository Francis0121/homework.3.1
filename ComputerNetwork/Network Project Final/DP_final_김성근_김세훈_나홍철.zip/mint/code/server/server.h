#include "../mint.h"

void tokenize(char* buf,int idx);
void request(char* command,char *body,int idx);
void response(char* command, char *body,int idx);